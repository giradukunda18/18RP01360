/* on my honor ,as a Rwanda ploytechinic/IPRC TUMBA student ,
I have  neither given nor received unauthorized assistance on this work.
author IRADUKUNDA Gilbert
date January 25,2021*/
class Car
{
	int count;
	String name;
	Engine engine;
	Wheel wheel;
	FluffyDice fluffyDice;

	Car(int count,String name,Engine engine,Wheel wheel,FluffyDice fluffyDice )
	{
		this.count=count;
		this.name=name;
		this.engine=engine;
		this.wheel=wheel;
		this.fluffyDice=fluffyDice;
	}
	void car()
	{
		System.out.println("car name is:"+name);
	}
	void setFluffyDice(FluffyDice fluffyDice)
	{
		System.out.println(fluffyDice);
	}
	String display()
	{
		
		System.out.println(engine);
		return null;
	}
}