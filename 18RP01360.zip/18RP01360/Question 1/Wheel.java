/* on my honor ,as a Rwanda ploytechinic/IPRC TUMBA student ,
I have  neither given nor received unauthorized assistance on this work.
author IRADUKUNDA Gilbert
date January 25,2021*/
public class Wheel
{
	int count;
	int position;

	Wheel()
	{
		this.count=count;
		this.position=position;
		
	}
	String display()
	{
		for (count=1;count<=4 ;count++ )
		 {
			System.out.println("I am a wheel no:"+count);	
		}
		return null;
	}


}