/* on my honor ,as a Rwanda ploytechinic/IPRC TUMBA student ,
I have  neither given nor received unauthorized assistance on this work.
author IRADUKUNDA Gilbert
date January 25,2021*/
public class FluffyDice
{
	String color;
	
	FluffyDice( String color)
	{
		this.color=color;
	}

	String display()
	{
		System.out.println("I am fluffy "+color);
		return null;
	}
}