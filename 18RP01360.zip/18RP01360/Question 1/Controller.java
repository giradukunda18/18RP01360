/* on my honor ,as a Rwanda ploytechinic/IPRC TUMBA student ,
I have  neither given nor received unauthorized assistance on this work.
author IRADUKUNDA Gilbert
date January 25,2021*/
public class Controller
{
public static void main(String[] args) 
{

		FluffyDice dice = new FluffyDice("red");
		Engine eng = new Engine();
		Wheel wheel1 = new Wheel();
		Car car1 = new Car(1,"BMW",eng,wheel1,dice);
		car1.car();
		eng.display();
		wheel1.display();
		dice.display();
		
		//car1.setFluffyDice();
	}	
}