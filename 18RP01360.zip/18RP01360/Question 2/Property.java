/* on my honor ,as a Rwanda ploytechinic/IPRC TUMBA student ,
I have  neither given nor received unauthorized assistance on this work.
author IRADUKUNDA Gilbert
date January 25,2021*/
class Property 
{
int bedroom;
int area;
int age;


Property(int bedroom,int area,int age)
{

this.bedroom=bedroom;
this.area=area;
this.age=age;

}
String display()
{	
	
	
	System.out.println("Bedroom:"+bedroom);
	System.out.println("Area:"+area);
	System.out.println("Age:"+age);

return null;
}
}