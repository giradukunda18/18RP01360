/* on my honor ,as a Rwanda ploytechinic/IPRC TUMBA student ,
I have  neither given nor received unauthorized assistance on this work.
author IRADUKUNDA Gilbert
date January 25,2021*/
class Car
{
	String plate_number;
	String manufactured;
	
	Car(String plate_number,String manufactured)
	{
		this.plate_number=plate_number;
		this.manufactured=manufactured;
		
	}
	String display()
	{	
		System.out.println("Plate number is:"+plate_number);
		System.out.println("manufactured:"+manufactured);
		return null;

	}
}