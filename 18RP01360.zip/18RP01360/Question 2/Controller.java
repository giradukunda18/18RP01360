/* on my honor ,as a Rwanda ploytechinic/IPRC TUMBA student ,
I have  neither given nor received unauthorized assistance on this work.
author IRADUKUNDA Gilbert
date January 25,2021*/
class Controller
{
	public static void main(String[] args) 
	{

		Item itm = new Item("house","property",10000);
		Property pro = new Property (4,500,5);
		Household house = new Household("used","http.pictre.com/flask");
		Car c1 = new Car("RAB123B","25/02/2021");
		c1.display();
		house.display();
		pro.display();	
	}
}