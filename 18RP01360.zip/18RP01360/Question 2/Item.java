/* on my honor ,as a Rwanda ploytechinic/IPRC TUMBA student ,
I have  neither given nor received unauthorized assistance on this work.
author IRADUKUNDA Gilbert
date January 25,2021*/
class Item
{
	String name;
	String category;
	double price;

	
	Item(String name, String category,double price)
	{
		this.name=name;
		this.category=category;
		this.price=price;
	}

}