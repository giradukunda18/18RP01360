package mygame;
class Server
{
	void getserver()
	{
		System.out.println("I am server");
	}
}