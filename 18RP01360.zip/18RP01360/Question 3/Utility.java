package mygame.utility;
public class Utility
{
	void getUtility()
	{
		System.out.println("I am utility");
	}
}