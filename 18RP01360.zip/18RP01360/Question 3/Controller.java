class controller
{
	public static void main(String[] args) 
	{
	Utility ut=new Utility();
	Server ser =new Server();
	Client cl =new Client();

		}
}